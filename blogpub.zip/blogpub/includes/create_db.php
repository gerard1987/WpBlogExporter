<?php
/**
 * Create databse tables and populate these with user blog input
 */
class create_db
{
	function populate_database(){
		global $wpdb;
		
		$user_id = $_POST['client_name'];
		$user_input = $_POST['comments'];
		$user_site = $_POST['blog_sites'];

		$table_name = $wpdb->prefix . "posts";

		$wpdb->insert(
				$table_name,
				array(
						'time' => current_time( 'mysql' ),
						'name' => $user_id,
                        'text' => $user_input,
                        "site" => $user_site,
				)
		);
	}
}