<?php
/*
 * Template Name: BlogPub Form
 */

get_header();
?>

<form id="blogPub_options" style="width: 100%; display: flex; flex-wrap: wrap; justify-content: center;" action="<?php echo home_url( '/' ); ?>/wp-content/plugins/blogpub.php" method="POST">

<h1>Please upload your blog</h1>
<label style="width: 100%;">Text version of youre blog</label>

<strong>Client name</strong>

<input style="width: 100%;" name="client_name" type="text" />

<strong>Blog title</strong>

<input style="width: 100%;" name="blog_title" type="text" />

Select target site

<select style="width: 100%;" name="blog_sites">
<option value="No Site Selected">[Choose Site Option Below]</option>
<option value="site_one">Blog one</option>
<option value="site_two">Blog two</option>
<option value="site_three">Blog three</option>
<option value="site_four">Blog four</option>
</select>

<textarea id="para1" style="width: 100%;" cols="35" name="comments" rows="12"></textarea>

<input type="submit" value="Submit">

</form>

<?php

die();
get_footer();

