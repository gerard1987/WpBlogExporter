<?php
/*
Plugin Name:  blogPub
Plugin URI:   http://www.waydesign.nl/blogPub
Description:  Retrieves file with same page slug as the url, gets the content from within a .docx file. Added support for page name shortcode [pagename]
Version:      0.1
Author:       http://www.waydesign.nl
Author URI:   http://www.waydesign.nl
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  wporg
Domain Path:  /languages
Shortcode Syntax: Default:[textload] || [textload type="textone"] || [textload type="texttwo"] || [telnr] || [pagename] [pagename type="location"]
*/

// Plugin updater

require 'plugin-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'https://advandm297.297.axc.nl/api/blogPub.json',
	__FILE__,
	'blogPub_updater'
);
// Plugin registration
register_activation_hook( __FILE__, array( 'blog_pub', 'install' ) );

// Define global constants
$plugin_dir = plugin_dir_path( __FILE__ );


// Includes
include_once $plugin_dir . 'includes/options_page.php';
include_once $plugin_dir . 'includes/create_db.php';
include_once $plugin_dir . 'includes/import_post.php';
include_once $plugin_dir . 'includes/db_retrieve_data.php';

require_once( wp_normalize_path(ABSPATH).'wp-load.php');

/**
 * @param blog_pub
 * 
 * @todo Needs content sanitizing or else will trow error on large content
 */
class blog_pub
{
    private  $is_user_logged_in;

    // Plugin install
    static function install() {
        // do not generate any output here
    }

    public function __construct(){

        $options_page = new options_page();

        // actions
        add_action('init', function(){
            $this-> is_user_logged_in = is_user_logged_in();
            
            $import_post = new import_post();
            $create_post = $import_post->create_post();

        });
    }
} // end of class

// create Instance's
$blog_pub = new blog_pub();
// $options_page = new options_page();
$create_db = new create_db();
// $import_post = new import_post();
// $db_retrieve_data = new db_retrieve_data();

// Add functions
// $add_to_database = $create_db->create_db_table();
// $populate_database = $create_db->populate_database();
// $connect_to_ext_serv = $db_retrieve_data->connect_to_ext_serv();
// $create_post = $import_post->create_post();
// $connect_to_db = $db_retrieve_data->connect_to_db();

// Register
register_activation_hook( __FILE__, 'create_db_table' );
// register_activation_hook( __FILE__, 'populate_database' );

?>