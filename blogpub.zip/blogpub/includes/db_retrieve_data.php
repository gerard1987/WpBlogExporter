<?php

/**
 * @param check_site
 * 
 */
class check_site
{
    function  user_defined_site($user_site)
    {
        // @TODO check for wich site has been selected, and define correct host data
        echo 'Db retrieve data user site :: ' .  $user_site . ' <br>';

        $options_page = new options_page();

        // Set Constants to variables to pass, for site check
        $site_one = $options_page::site_one;
        $site_two = $options_page::site_two;
        $site_three = $options_page::site_three;
        $site_four = $options_page::site_four;

        $db_object = (object) [
                'db_host' => '',
                'db_user' => '',
                'db_pass' => '',
                'db_name' => '',
                'db_port' => '',
                'db_prefix' => ''
        ];

        switch ($user_site)
        {
            case $site_one:
                echo 'Site one and User_site Match !';
                // The Locksmith
                $db_object = (object) [
                    'db_host' => '185.182.59.41',
                    'db_user' => 'advanxi310_wp955',
                    'db_pass' => '17RS]Ip0@U',
                    'db_name' => 'advanxi310_wp955',
                    'db_port' => '3306',
                    'db_prefix' => 'wpdr_posts'
                ];             
                break;
            case $site_two:
                echo 'site_two and User_site Match !';
                // sloten-webshop 
                $db_object = (object) [
                    'db_host' => '185.182.59.41',
                    'db_user' => 'advanxi310_wp865',
                    'db_pass' => '5Stm-46p-0',
                    'db_name' => 'advanxi310_wp865',
                    'db_port' => '3306',
                    'db_prefix' => 'wpmt_posts'
                ];
                break;
            case $site_three:
                echo 'site_three and User_site Match !';
                // deslotenexpert
                $db_object = (object) [
                    'db_host' => '185.182.59.41',
                    'db_user' => 'advanxi310_wp742',
                    'db_pass' => ']7P1XSpp1.',
                    'db_name' => 'advanxi310_wp742',
                    'db_port' => '3306',
                    'db_prefix' => 'wp8i_posts'
                ];
                break;
            case $site_four:
                echo 'site_four and User_site Match !';
                // Slotenmaker belgie
                $db_object = (object) [
                    'db_host' => '185.182.59.41',
                    'db_user' => 'advanxi310_test',
                    'db_pass' => 'YicxTHakw',
                    'db_name' => 'advanxi310_test',
                    'db_port' => '3306',
                    'db_prefix' => 'wp_posts'
                ];
                break;
            default:
                exit;
        }

        $db_retrieve_data = new db_retrieve_data();
        $db_retrieve_data->connect_to_db($user_site, $db_object);
    return;
        
    }
} // End of class

/**
 * Create databse tables and populate these with user blog input
 */
class db_retrieve_data 
{

    function connect_to_db($user_site, $db_object){
        global $wpdb;

        $results = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}posts WHERE post_status = 'publish' and post_type = 'post' ");
        
            $db_retrieve_data = new db_retrieve_data();
            $db_retrieve_data->connect_to_ext_serv($results, $user_site, $db_object);
    }

    function connect_to_ext_serv($results, $user_site, $db_object){

        // Define constants, for sql

        define('BLOGP_DB_HOST', $db_object->db_host);
        define('BLOGP_DB_USER', $db_object->db_user);
        define('BLOGP_DB_PASS', $db_object->db_pass);
        define('BLOGP_DB_NAME', $db_object->db_name);
        define('BLOGP_DB_PORT', $db_object->db_port);
        define('PREFIX', $db_object->db_prefix);

        // Get Constants for connection
        $check_site = new check_site();

        // Break function For testing

        // Create column for site data
        try {
            $connection = new PDO( 'mysql:host=' . BLOGP_DB_HOST . '; dbname=' . BLOGP_DB_NAME, BLOGP_DB_USER, BLOGP_DB_PASS );

            // set the PDO error mode to exception
            $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // $sql_string = "ALTER TABLE " . "`" . PREFIX . "`" . " ADD COLUMN IF NOT EXISTS `blogpub_sitedata` VARCHAR(255) NOT NULL;";
            
            $new_statement = $connection->prepare("ALTER TABLE " . "`" . PREFIX . "`" . " ADD COLUMN IF NOT EXISTS `blogpub_sitedata` VARCHAR(255) NOT NULL;");
            $new_inserted = $new_statement->execute();
        }
        catch(PDOException $error) {
            echo 'Error: ' . $error->getMessage() . "<br/>";
            exit;
        }

        $post_array = $results;

        foreach ($post_array as $item){
            $post_author = $item->post_author;
            $post_date = $item->post_date;
            $post_date_gmt = $item->post_date_gmt;
            $post_content = $item->post_content;
            $post_title = $item->post_title;
            $post_excerpt = $item->post_excerpt;
            $post_status = $item->post_status;
            $comment_status = $item->comment_status;
            $ping_status = $item->ping_status;
            $post_password = $item->post_password;
            $post_name = $item->post_name;
            $to_ping = $item->to_ping;
            $pinged = $item->pinged;
            $post_modified = $item->post_modified;
            $post_modified_gmt = $item->post_modified_gmt;
            $post_content_filtered = $item->post_content_filtered;
            $post_parent = $item->post_parent;
            $menu_order = $item->menu_order;
            $post_type = $item->post_type;
            $post_mime_type = $item->post_mime_typadvanxi310_blogs;
            $comment_count = $item->comment_count;
            $blogpub_sitedata = $user_site;
        }

        global $wpdb;

        $blogpub_sitedata = $user_site;

        try {
            $connection = new PDO( 'mysql:host=' . BLOGP_DB_HOST . '; dbname=' . BLOGP_DB_NAME, BLOGP_DB_USER, BLOGP_DB_PASS );

            // set the PDO error mode to exception
            $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // For debugging the connection
            echo 'Connected successfully';

            $sql = "INSERT INTO " . PREFIX . "(
                post_author,
                post_date, 
                post_date_gmt, 
                post_content, 
                post_title, 
                post_excerpt, 
                post_status, 
                comment_status, 
                ping_status, 
                post_password, 
                post_name,
                to_ping,
                pinged,
                post_modified,
                post_modified_gmt,
                post_content_filtered,
                post_parent,
                menu_order,
                post_type,
                post_mime_type,
                comment_count,
                blogpub_sitedata
                  ) 
            VALUES (
                '$post_author',
                '$post_date',
                '$post_date_gmt',
                '$post_content',
                '$post_title',
                '$post_excerpt',
                '$post_status',
                '$comment_status',
                '$ping_status',
                '$post_password',
                '$post_name',
                '$to_ping',
                '$pinged',
                '$post_modified',
                '$post_modified_gmt',
                '$post_content_filtered',
                '$post_parent',
                '$menu_order',
                '$post_type',
                '$post_mime_type',
                '$comment_count',
                '$blogpub_sitedata'
            )";

            //Prepare our statement.
            $statement = $connection->prepare($sql);
            var_dump($statement);
            
            //Execute the statement and insert our values.
            $inserted = $statement->execute();

            //Because PDOStatement::execute returns a TRUE or FALSE value,
            //we can easily check to see if our insert was successful.
            if($inserted){
                echo 'Row inserted!<br>';
            }
            
            exit;            
        }
        catch(PDOException $error) {
            echo 'Error: ' . $error->getMessage() . "<br/>";
            exit;
        }

    }
}