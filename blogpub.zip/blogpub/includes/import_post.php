<?php
/**
 * Import wp post
 */
class import_post
{
    public function __construct(){
		add_action('init', array($this, 'create_post'));
    }
	
	public function create_post(){
		$running = false;
		// Get input
		if(isset($_POST['blog_title'])) {

			$blog_title = $_POST['blog_title'];
			$user_id = $_POST['client_name'];
			$user_site = $_POST['blog_sites'];
			$user_input = wp_check_invalid_utf8($_POST['blogpubeditor'], true);

			// $untrusted_input = '<script type="text/javascript">';
			
			// if (strpos($user_input, $_POST['blogpubeditor']) !== false){
			// 	$user_input = wp_check_invalid_utf8($_POST['blogpubeditor'], true);
			// }
	
			global $user_ID;
	
			$new_post = array(
				'post_title' => $blog_title,
				'post_content' => $user_input,
				'post_status' => 'publish',
				'post_date' => date('Y-m-d H:i:s'),
				'post_author' => $user_ID,
				'post_type' => 'post',
				'post_category' => array(0)
			);
			$post_id = wp_insert_post($new_post);

			$running = true;
		}
		if (isset($post_id) && $running === true){

			$is_running = true;
			if ($is_running === true){

				$check_site = new check_site();
				$check_site->user_defined_site($user_site);


				// $url = 'https://test.fotograaf-inhuren.com/bedankt-2/';
				// wp_redirect($url);

				// $db_retrieve_data = new db_retrieve_data();
				// $db_retrieve_data->connect_to_db($user_site);

				$is_running = false;
			}
			exit;
		}
	}
}